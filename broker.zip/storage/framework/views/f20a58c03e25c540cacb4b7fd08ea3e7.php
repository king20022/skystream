<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>:: Exquisitecryptoventures | Platform for Virtual Currencies That Is Straightforward, Secure, and Reliable</title>
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="/asset/plugins/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/https://fonts.googleapis.com/icon?family=Material+Icons">
    <!-- Custom Css -->
    <link rel="stylesheet" href="/asset/css/main.css">
    <link rel="stylesheet" href="/asset/css/themes/all-themes.css" />

</head>

<body class="theme-blush">
    

    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->

    

    <!-- Top Bar -->
    <nav class="navbar clearHeader">
        <div class="col-12">
            <div class="navbar-header"> <a href="javascript:void(0);" class="bars"></a> <a class="navbar-brand"
                    href="#">Exquisitecryptoventures</a> </div>
            <ul class="nav navbar-nav navbar-right">
                
                <!-- Tasks -->
                
            </ul>
        </div>
    </nav>
    <!-- #Top Bar -->





    <?php echo e($slot); ?>

    <?php if(Auth::user()->role == 'admin'): ?>
        <?php if (isset($component)) { $__componentOriginal2812d824e80b3a65bceda8e6a9bfa7a0 = $component; } ?>
<?php $component = App\View\Components\Admin::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2812d824e80b3a65bceda8e6a9bfa7a0)): ?>
<?php $component = $__componentOriginal2812d824e80b3a65bceda8e6a9bfa7a0; ?>
<?php unset($__componentOriginal2812d824e80b3a65bceda8e6a9bfa7a0); ?>
<?php endif; ?>
    <?php elseif(Auth::user()->role == 'investor'): ?>
        <?php if (isset($component)) { $__componentOriginal003a556deefb540d3b13176d32b3e4d2 = $component; } ?>
<?php $component = App\View\Components\Investor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('investor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Investor::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal003a556deefb540d3b13176d32b3e4d2)): ?>
<?php $component = $__componentOriginal003a556deefb540d3b13176d32b3e4d2; ?>
<?php unset($__componentOriginal003a556deefb540d3b13176d32b3e4d2); ?>
<?php endif; ?>
    <?php endif; ?>

    

    <!-- Jquery Core Js -->
    <script src="asset/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
    <script src="asset/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
    <script src="asset/bundles/morphingsearchscripts.bundle.js"></script> <!-- Main top morphing search -->

    <script src="asset/plugins/jquery-sparkline/jquery.sparkline.min.js"></script> <!-- Sparkline Plugin Js -->
    <script src="asset/plugins/chartjs/Chart.bundle.min.js"></script> <!-- Chart Plugins Js -->

    <script src="asset/bundles/mainscripts.bundle.js"></script><!-- Custom Js -->
    <script src="asset/js/pages/charts/sparkline.min.js"></script>
    <script src="asset/js/pages/index.js"></script>
</body>



</html>
<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\GCCR\broker\resources\views/layouts/app.blade.php ENDPATH**/ ?>