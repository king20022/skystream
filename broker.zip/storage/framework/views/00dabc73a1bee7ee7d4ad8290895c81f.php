
<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Sky Stream Exchange</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="logobroker.png" />
    <!-- Custom Stylesheet -->

    <link rel="stylesheet" href="/email/css/style.css" />
</head>

<body class="@dashboard">


    <div id="preloader"><i>.</i><i>.</i><i>.</i></div>


    <div id="main-wrapper">

        <div class="authincation section-padding">
            <div class="container h-100">
                <div class="row justify-content-center h-100 align-items-center">
                    <div class="col-xl-4 col-md-5">
                        <div class="mini-logo text-center my-3">
                            <a href="<?php echo e(route ('welcome')); ?>"><img src="logobroker.png" alt=""></a>
                            <h4 class="card-title mt-5">Reset Password</h4>
                        </div>
                        <div>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="edit page"></label>
                                <p class="text-danger text-center"><?php echo e($err); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="auth-form card">
                            <div class="card-body">
                                <form action="<?php echo e(route('password.store')); ?>" class="row g-3" method="POST"><?php echo csrf_field(); ?>
                                    <!-- Password Reset Token -->
                                    <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">
                                    <div class="col-12">
                                        <label class="form-label">Email</label>

                                        <input class="form-control" id="email" name="email"
                                            :value="old('email', $request - > email)" required autofocus
                                            autocomplete="username"">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Password</label>

                                        <input type="password" class="form-control" name="password" id="password"
                                            required autofocus placeholder="***********"  autocomplete="new-password">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Confirm Password</label>

                                        <input  type="password" class="form-control" name="password_confirmation" id="password_confirmation"
                                            required autofocus placeholder="***********"  autocomplete="new-password">
                                    </div>




                                    <div class="text-center mt-4">
                                        <button class="btn btn-primary btn-block">Reset Password</button>

                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>



    <script src="/email/vendor/jquery/jquery.min.js"></script>
    <script src="/email/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


















    <script src="/email/js/scripts.js"></script>


</body>


</html>
<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\balotelli\broker\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>