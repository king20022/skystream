<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="d-sm-flex justify-content-between">
                    <div>
                        <h2>All investors</h2>
                        <small class="text-muted">Welcome Admin</small>
                    </div>

                </div>
            </div>
            <div class="row clearfix">


                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                        <div class="card">
                            <div class="body">
                                <div class="member-card verified">
                                    <div class="thumb-xl member-thumb">
                                        <img src="asset/images/random-avatar3.jpg" class="img-thumbnail rounded-circle"
                                            alt="profile-image">
                                    </div>

                                    <div class="m-t-20">
                                        <h4 class="m-b-0"><?php echo e($user->name); ?></h4>
                                        <p class="text-muted"><?php echo e($user->number); ?><span> <a href="#"
                                                    class="text-pink"><?php echo e($user->email); ?></a> </span></p>
                                    </div>

                                    <p class="text-muted"><?php echo e($user->address); ?></p>

                                    <a href="<?php echo e(route('admin.edit', $user->id)); ?>"
                                        class="btn bg-success btn-raised ">Edit
                                        Profile</a>

                                    <a href="<?php echo e(route('admin.delete', ['user_id' => $user->id])); ?>"
                                        onclick="event.preventDefault();
                                                     if (confirm('Are you sure you want to delete this Investor?')) {
                                                         document.getElementById('delete-user-form').submit();
                                                     }">
                                        <div class="col-sm-12">
                                            <button class="btn btn-raised g-bg-blush2"> Delete Investor</button>
                                        </div>

                                    </a>

                                    <form id="delete-user-form"
                                        action="<?php echo e(route('admin.delete', ['user_id' => $user->id])); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
    <!-- main content -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\balotelli\broker\resources\views/Admin/investors.blade.php ENDPATH**/ ?>