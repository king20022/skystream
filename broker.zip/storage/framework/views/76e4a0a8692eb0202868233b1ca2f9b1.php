<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="d-sm-flex justify-content-between">

                    <div>
                    <a href="<?php echo e(route ('investor.coin')); ?>" class="btn btn-raised btn-primary">Fund Account</a>
                    </div>

                </div>
            </div>
            <div class="row clearfix">


                
                    <div class="col-xl-3 col-lg-7 col-md-6 col-sm-12 mr-0">
                        <div class="card shadow-2xl">
                            <div class="body">
                                <div class="member-card verified text-left ">

                                    <p class="text-pink mb-0"><b class="h6">Available Balance</b></p>
                                    <p class="text-pink mt-3"><i class="h5">$ </i><span class="h5"><?php echo e($user->balance); ?></span></p>
                                    <p class="text-muted"> <b> </b></p>


                                </div>


                            </div>
                        </div>
                    </div>
                


            </div>
        </div>
    </section>
    <!-- main content -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\GCCR\broker\resources\views/Investor/deposit.blade.php ENDPATH**/ ?>