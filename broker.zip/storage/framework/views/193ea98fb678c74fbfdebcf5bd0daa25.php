<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="d-sm-flex justify-content-between">
                    <div>
                        <h2>All Investment</h2>
                        <small class="text-muted">Welcome Admin</small>

                    </div>
                    <div>
                        <a href="<?php echo e(route('admin.investment')); ?>" class="btn btn-raised btn-primary">Add Investment</a>
                    </div>

                </div>
            </div>
            <div class="row clearfix">


                <?php $__currentLoopData = $investment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12">
                        <div class="card">
                            <div class="body">
                                <div class="member-card verified">
                                    <div class="m-t-20">

                                        <p class="text-pink mb-0">Plan</p>
                                        <p class="text-muted"> <b><?php echo e($investment->plan); ?> </b><span></p>
                                        <p class="text-pink mb-0">Amount</p>
                                        <p class="text-muted"> <b><?php echo e($investment->amount); ?> </b></p>

                                    </div>
                                    <p class="text-pink mb-0">Profit</p>
                                    <p class="text-muted"> <b><?php echo e($investment->profit); ?> </b></p>
                                    <p class="text-pink mb-0">Duration</p>
                                    <p class="text-muted"> <b><?php echo e($investment->duration); ?> </b></p>
                                    

                                    <form method="POST" action="/investments/<?php echo e($investment->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn bg-danger btn-raised">Delete</button>
                                    </form>


                                </div>


                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
    <!-- main content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\balotelli\broker\resources\views/Admin/addinvestment.blade.php ENDPATH**/ ?>