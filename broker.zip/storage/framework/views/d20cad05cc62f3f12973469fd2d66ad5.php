<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- main content -->
    <section class="content home">
        <div class="container-fluid">
            <div class="block-header">
                <div class="d-sm-flex justify-content-between">
                    <div>
                        <h2>Dashboard</h2>
                        <small class="text-muted">Welcome  Admin </small>
                    </div>

                </div>
            </div>

            
            <div class="row clearfix">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="body">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div class="tradingview-widget-container__widget"></div>
                                <div class="tradingview-widget-copyright"></div>
                                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-technical-analysis.js"
                                    async>
                                    {
                                        "interval": "1m",
                                        "width": 425,
                                        "isTransparent": false,
                                        "height": 425,
                                        "symbol": "NASDAQ:AAPL",
                                        "showIntervalTabs": true,
                                        "locale": "en",
                                        "colorTheme": "dark"
                                    }
                                </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card">

                        <div class="body">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div class="tradingview-widget-container__widget"></div>
                                <div class="tradingview-widget-copyright">
                                </div>
                                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js"
                                    async>
                                    {
                                        "symbol": "FX:EURUSD",
                                        "width": "425",
                                        "height": "425",
                                        "locale": "en",
                                        "dateRange": "12M",
                                        "colorTheme": "dark",
                                        "trendLineColor": "rgba(41, 98, 255, 1)",
                                        "underLineColor": "rgba(41, 98, 255, 0.3)",
                                        "underLineBottomColor": "rgba(41, 98, 255, 0)",
                                        "isTransparent": false,
                                        "autosize": false,
                                        "largeChartUrl": ""
                                    }
                                </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
            </div>
            

        </div>
    </section>
    <!-- main content -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Desktop\FRONTEND-FILES\GCCR\broker\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>